#!/usr/bin/env python3
"""Nebula Wizard - core operations.

Handles builds from a hosted repository or a local folder, single-addon
zip installs, theme switching and update checks.
"""

import glob
import hashlib
import json
import os
import shutil
import sqlite3
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

HOME = xbmcvfs.translatePath("special://home/")
ADDONS_DIR = os.path.join(HOME, "addons")
TEMP = xbmcvfs.translatePath("special://temp/")
PACKAGES = os.path.join(ADDONS_DIR, "packages")

THEMES = ["Midnight", "Crimson", "Ocean", "Ember", "Emerald", "Violet"]

FALLBACK_URLS = ["https://nebulabuilds.vercel.app"]


def _latest_db(prefix):
    db_dir = xbmcvfs.translatePath("special://database/")
    best = None
    try:
        for name in os.listdir(db_dir):
            if name.startswith(prefix) and name.endswith(".db"):
                num = name[len(prefix):-3]
                if num.isdigit() and (best is None or int(num) > int(best)):
                    best = num
    except OSError:
        return None
    if best is None:
        return None
    return os.path.join(db_dir, "%s%s.db" % (prefix, best))


ADDONS_DB = _latest_db("Addons")

EXCLUDES_INSTALL = [ADDON_ID, "kodi.log", "Addons33.db", "packages", "backups"]
if ADDONS_DB:
    db_name = os.path.basename(ADDONS_DB)
    if db_name not in EXCLUDES_INSTALL:
        EXCLUDES_INSTALL.append(db_name)

KEEP_DIRS = ("addons", "userdata", "Database", "addon_data", "backups", "temp")


def log(msg):
    xbmc.log("[NebulaWizard] %s" % msg, xbmc.LOGINFO)


def notify(title, msg, icon="special://skin/media/logo.png"):
    xbmcgui.Dialog().notification(title, msg, icon, 5000)


def get_url(url, timeout=45):
    req = urllib.request.Request(url, headers={"User-Agent": "NebulaBuilds/1.0"})
    return urllib.request.urlopen(req, timeout=timeout).read()


def _split_list(raw):
    return [u.strip().rstrip("/") for u in raw.split(",") if u.strip()]


def get_base_urls():
    """Primary base URL first, then mirrors, then built-in fallbacks."""
    return _split_list(ADDON.getSetting("base_url")) + \
        _split_list(ADDON.getSetting("mirrors")) + \
        list(FALLBACK_URLS)


def _join(base, rel):
    return base.rstrip("/") + "/" + rel.lstrip("/")


def _is_local(base):
    return base.startswith("special://") or base.startswith("/") or \
        base.startswith("file://")


def fetch_first(rel):
    """Try each base URL until one serves rel; raise with the last error."""
    last = None
    for base in get_base_urls():
        url = _join(base, rel)
        try:
            data = get_url(url)
            log("fetched %s from %s" % (rel, base))
            return data, url
        except Exception as e:
            last = e
            log("mirror failed for %s: %s (%s)" % (url, e, type(e).__name__))
    raise RuntimeError("All repository URLs failed for %s: %s" % (rel, last))


def fetch_json(rel):
    data, _ = fetch_first(rel)
    return json.loads(data.decode("utf-8"))


def source_url(rel):
    """Local filesystem path for a repo file (first local base wins)."""
    for base in get_base_urls():
        if _is_local(base):
            return os.path.join(xbmcvfs.translatePath(base), rel)
    raise RuntimeError("No local repository URL configured for %s" % rel)


def ensure_local(rel):
    """Return a local filesystem path for rel, downloading if remote."""
    for base in get_base_urls():
        if _is_local(base):
            return os.path.join(xbmcvfs.translatePath(base), rel)
    dest = os.path.join(TEMP, os.path.basename(rel))
    data, _ = fetch_first(rel)
    log("downloading %s -> %s" % (rel, dest))
    with open(dest, "wb") as f:
        f.write(data)
    return dest


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def list_builds():
    return fetch_json("builds/builds.json")["builds"]


def _enable_addon(addon_id):
    try:
        xbmc.executebuiltin("Addon.SetEnabled(%s,true)" % addon_id)
    except Exception as e:
        log("could not enable %s: %s" % (addon_id, e))


def apply_theme(theme):
    if not ADDON.getSettingBool("auto_theme"):
        return
    if theme and theme in THEMES:
        try:
            rpc = ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue",'
                   '"params":{"setting":"lookandfeel.skincolors",'
                   '"value":"%s"},"id":1}') % theme.lower()
            xbmc.executeJSONRPC(rpc)
            log("theme applied: %s" % theme)
        except Exception as e:
            log("theme failed: %s" % e)


def _build_skin(build):
    for addon_id in build.get("addons", []):
        if addon_id.startswith("skin."):
            return addon_id
    return None


def set_skin(skin_id):
    """Activate the build's skin so Kodi boots into it after restart."""
    try:
        rpc = ('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled",'
               '"params":{"addonid":"%s","enabled":true},"id":1}') % skin_id
        xbmc.executeJSONRPC(rpc)
        log("enabled skin %s" % skin_id)
    except Exception as e:
        log("could not enable skin %s: %s" % (skin_id, e))
    try:
        rpc = ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue",'
               '"params":{"setting":"lookandfeel.skin","value":"%s"},"id":1}') % skin_id
        result = xbmc.executeJSONRPC(rpc)
        log("set active skin to %s: %s" % (skin_id, result))
    except Exception as e:
        log("could not set skin %s: %s" % (skin_id, e))


def _safe_extract(zip_path, dest):
    """Pure-Python zip extraction (no xbmcvfs.extract - avoids platform quirks)."""
    log("extracting %s -> %s (python zipfile)" % (zip_path, dest))
    dest = os.path.abspath(dest)
    try:
        os.makedirs(dest, exist_ok=True)
    except OSError as e:
        raise RuntimeError("Cannot create %s: %s" % (dest, e))
    try:
        with zipfile.ZipFile(zip_path) as zf:
            for member in zf.infolist():
                target = os.path.abspath(os.path.join(dest, member.filename))
                if target != dest and not target.startswith(dest + os.sep):
                    raise RuntimeError("Unsafe path in archive: %s" % member.filename)
                if member.is_dir():
                    os.makedirs(target, exist_ok=True)
                    continue
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with zf.open(member) as src, open(target, "wb") as out:
                    shutil.copyfileobj(src, out, 1 << 20)
                mode = (member.external_attr >> 16) & 0x1FF
                if mode:
                    try:
                        os.chmod(target, mode)
                    except OSError:
                        pass
    except RuntimeError:
        raise
    except Exception as e:
        raise RuntimeError("Failed to extract %s: %s"
                           % (os.path.basename(zip_path), e))


def extract_zip(zip_path, dest):
    _safe_extract(zip_path, dest)


def _version_tuple(version):
    return tuple(int(p) for p in str(version).split(".") if p.isdigit())


def swap_to_estuary():
    if xbmc.getSkinDir() in ("skin.estuary",):
        return
    try:
        rpc = ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue",'
               '"params":{"setting":"lookandfeel.skin",'
               '"value":"skin.estuary"},"id":1}')
        xbmc.executeJSONRPC(rpc)
        x = 0
        xbmc.sleep(100)
        while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
            x += 1
            xbmc.sleep(100)
            xbmc.executebuiltin("SendAction(Select)")
        if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
            xbmc.executebuiltin("SendClick(11)")
        xbmc.sleep(500)
        log("swapped to estuary, skin now: %s" % xbmc.getSkinDir())
    except Exception as e:
        log("skin swap to estuary failed: %s" % e)


def fresh_start():
    """Wipe installed addons (keep the wizard, packages, backups, DB) before a build."""
    swap_to_estuary()
    progress = xbmcgui.DialogProgress()
    progress.create("Nebula Wizard", "Deleting files and folders ...")
    xbmc.sleep(100)
    progress.update(30, "Deleting files and folders ...")
    xbmc.sleep(100)
    root_path = os.path.abspath(HOME)
    for root, dirs, files in os.walk(root_path, topdown=True):
        dirs[:] = [d for d in dirs if d not in EXCLUDES_INSTALL and d != "userdata"]
        for name in files:
            if name not in EXCLUDES_INSTALL:
                try:
                    os.remove(os.path.join(root, name))
                except OSError:
                    log("unable to delete %s" % name)
    progress.update(60, "Deleting files and folders ...")
    xbmc.sleep(100)
    for root, dirs, files in os.walk(root_path, topdown=True):
        dirs[:] = [d for d in dirs if d not in EXCLUDES_INSTALL and d != "userdata"]
        for name in dirs:
            if name not in KEEP_DIRS:
                try:
                    shutil.rmtree(os.path.join(root, name), ignore_errors=True)
                except OSError:
                    pass
    progress.update(100, "Done")
    xbmc.sleep(1000)
    if not os.path.isdir(PACKAGES):
        os.makedirs(PACKAGES, exist_ok=True)
    progress.close()


def download_build_zip(build, progress):
    """Download a build zip to addons/packages/tempzip.zip with progress + cancel."""
    if not os.path.isdir(PACKAGES):
        os.makedirs(PACKAGES, exist_ok=True)
    dest = os.path.join(PACKAGES, "tempzip.zip")
    if os.path.exists(dest):
        os.unlink(dest)
    rel = _join("builds", build["file"])
    last = None
    for base in get_base_urls():
        if _is_local(base):
            try:
                shutil.copyfile(os.path.join(xbmcvfs.translatePath(base), rel), dest)
                log("staged %s from local base" % rel)
                return dest
            except Exception as e:
                last = e
                continue
        url = _join(base, rel)
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "NebulaBuilds/1.0"})
            resp = urllib.request.urlopen(req, timeout=60)
            length = resp.headers.get("Content-Length")
            size = 0
            cancelled = False
            with open(dest, "wb") as f:
                while True:
                    if progress.iscanceled():
                        cancelled = True
                        break
                    chunk = resp.read(1 << 20)
                    if not chunk:
                        break
                    size += len(chunk)
                    f.write(chunk)
                    if length:
                        pct = min(100, int(size * 100 / max(int(length), 1)))
                        progress.update(pct, "Downloading %s ...\n%d / %d MB"
                                        % (build.get("file", ""), size >> 20, int(length) >> 20))
                    else:
                        progress.update(-1, "Downloading %s ...\n%d MB"
                                        % (build.get("file", ""), size >> 20))
            if cancelled:
                os.unlink(dest)
                raise RuntimeError("Download cancelled.")
            log("downloaded %s from %s" % (rel, url))
            return dest
        except RuntimeError:
            raise
        except Exception as e:
            last = e
            log("mirror failed for %s: %s" % (url, e))
    raise RuntimeError("All repository URLs failed for %s: %s" % (rel, last))


def truncate_addons_db():
    if not ADDONS_DB or not os.path.exists(ADDONS_DB):
        return
    con = None
    try:
        con = sqlite3.connect(ADDONS_DB)
        cur = con.cursor()
        for table in ("addonlinkrepo", "addons", "package", "repo", "update_rules", "version"):
            try:
                cur.execute("DELETE FROM %s;" % table)
            except sqlite3.Error:
                pass
        con.commit()
        log("truncated addons database")
    except sqlite3.Error as e:
        log("failed to truncate addons db: %s" % e)
    finally:
        if con:
            con.close()


def _db_enable(addon_id):
    if not ADDONS_DB or not os.path.exists(ADDONS_DB):
        return
    con = None
    try:
        con = sqlite3.connect(ADDONS_DB)
        cur = con.cursor()
        cur.execute("SELECT id FROM installed WHERE addonID = ?", (addon_id,))
        if cur.fetchone() is None:
            cur.execute("INSERT INTO installed (addonID, enabled, installDate) VALUES (?,?,?)",
                        (addon_id, "1", "NebulaBuilds"))
        else:
            cur.execute("UPDATE installed SET enabled = ? WHERE addonID = ?", (1, addon_id))
        con.commit()
    except sqlite3.Error as e:
        log("failed to enable %s: %s" % (addon_id, e))
    finally:
        if con:
            con.close()


def enable_wizard():
    _db_enable(ADDON_ID)


def enable_addons():
    try:
        for name in glob.glob(os.path.join(ADDONS_DIR, "*/addon.xml")):
            try:
                addon_id = ET.parse(name).getroot().get("id")
            except Exception:
                continue
            if addon_id:
                _db_enable(addon_id)
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("UpdateAddonRepos")
    except Exception as e:
        log("enable_addons failed: %s" % e)


def _remove_addon(addon_id):
    target = os.path.join(ADDONS_DIR, addon_id)
    if os.path.isdir(target):
        shutil.rmtree(target, ignore_errors=True)
        log("removed existing addon %s" % addon_id)


def install_addon_zip(zip_path):
    """Install a single addon zip (folder <addonid>/ at root)."""
    progress = xbmcgui.DialogProgress()
    progress.create("Nebula Wizard", "Installing addon ...")
    extract_zip(zip_path, ADDONS_DIR)
    progress.close()
    notify("Nebula Wizard", "Addon installed - restart recommended")
    return True


def install_build(build):
    """Install a build exactly like a standard wizard: wipe, extract, register, exit."""
    progress = xbmcgui.DialogProgress()
    progress.create("Nebula Wizard", build.get("name", "Build"))
    progress.update(0, "Downloading %s ..." % build.get("file", ""))

    zip_path = download_build_zip(build, progress)
    if build.get("sha256"):
        progress.update(30, "Verifying download ...")
        if sha256_file(zip_path) != build["sha256"]:
            raise RuntimeError("Download failed integrity check - retry the build.")

    fresh_start()
    progress.update(45, "Extracting ...")
    extract_zip(zip_path, HOME)
    if os.path.exists(zip_path):
        os.unlink(zip_path)

    progress.update(80, "Applying build ...")
    skin_id = _build_skin(build)
    if skin_id:
        set_skin(skin_id)
    apply_theme(build.get("theme"))

    ADDON.setSetting("buildname", build.get("name", "Unknown Build"))
    ADDON.setSetting("buildversion", build.get("version", "0"))
    ADDON.setSetting("firstrun", "true")
    enable_wizard()
    enable_addons()
    truncate_addons_db()

    progress.update(100, "Done")
    progress.close()
    xbmcgui.Dialog().ok("Nebula Wizard",
                        "%s installed.\n\nForce-close Kodi now - it reopens with the build active."
                        % build.get("name"))
    os._exit(1)


def _human_size(num):
    try:
        num = int(num)
    except (TypeError, ValueError):
        return "?"
    for unit in ("B", "KB", "MB", "GB"):
        if num < 1024 or unit == "GB":
            return "%d %s" % (num, unit) if unit == "B" else "%.1f %s" % (num, unit)
        num /= 1024.0
    return "?"


def pick_build(progress_cb=None):
    try:
        builds = list_builds()
    except Exception as e:
        notify("Nebula Wizard", "Could not load builds: %s" % e, xbmcgui.NOTIFICATION_ERROR)
        return None
    if not builds:
        notify("Nebula Wizard", "No builds found.", xbmcgui.NOTIFICATION_ERROR)
        return None

    items = ["%s v%s  (%s)" % (b["name"], b["version"], _human_size(b.get("size")))
             for b in builds]
    idx = xbmcgui.Dialog().select("Nebula Builds", items)
    if idx < 0:
        return None
    build = builds[idx]
    if not xbmcgui.Dialog().yesno("Nebula Wizard", "Install %s?" % build["name"],
                                  build.get("description", "")):
        return None
    return build


def run_install_build():
    build = pick_build()
    if not build:
        return
    try:
        install_build(build)
    except Exception as e:
        notify("Nebula Wizard", "Install failed: %s" % e, xbmcgui.NOTIFICATION_ERROR)
        return


def run_install_zip():
    path = xbmcgui.Dialog().browse(1, "Install addon zip", "files",
                                   ".zip", False, False)
    if not path:
        return
    try:
        install_addon_zip(path)
    except Exception as e:
        notify("Nebula Wizard", "Zip install failed: %s" % e, xbmcgui.NOTIFICATION_ERROR)
        return
    if xbmcgui.Dialog().yesno("Nebula Wizard", "Restart now?"):
        xbmc.executebuiltin("Reboot")


def run_theme():
    idx = xbmcgui.Dialog().select("Nebula Theme", THEMES)
    if idx >= 0:
        apply_theme(THEMES[idx])
        notify("Nebula Wizard", "Theme set to %s" % THEMES[idx])


def run_update():
    try:
        builds = list_builds()
        notify("Nebula Wizard", "%d build(s) available" % len(builds))
    except Exception as e:
        notify("Nebula Wizard", "Update check failed: %s" % e, xbmcgui.NOTIFICATION_ERROR)


def run_about():
    xbmcgui.Dialog().textviewer("Nebula Wizard",
                                "Nebula Builds\n\n"
                                "One-tap builds for Kodi 20-22.\n\n"
                                "Install Build  - fetch and install a build from the repository.\n"
                                "Install Zip    - install a single addon from a local zip.\n"
                                "Check Updates  - refresh the build list from the repository.\n"
                                "Nebula Theme   - switch the skin accent theme.\n\n"
                                "Set the repository URL in the add-on settings.")
