#!/usr/bin/env python3
"""Nebula Wizard - startup service. Matches standard build-wizard boot behavior."""

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib import wizard

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")


def wait_seconds(seconds):
    for _ in range(seconds):
        if xbmc.abortRequested:
            return False
        xbmc.sleep(1000)
    return True


def open_build_installer():
    xbmc.executebuiltin('ActivateWindow(10001, "plugin://%s/?action=build",return)' % ADDON_ID)


def run_startup():
    if not wait_seconds(15):
        return
    try:
        if ADDON.getSetting("firstrun") == "true":
            wizard.enable_wizard()
            wizard.enable_addons()
            ADDON.setSetting("firstrun", "false")
            return
    except Exception as e:
        wizard.log("startup first-run handling failed: %s" % e)
    try:
        buildname = ADDON.getSetting("buildname")
        if not buildname or buildname == "No Build Installed":
            choice = xbmcgui.Dialog().yesnocustom(
                "Nebula Wizard",
                "There is currently no build installed.\nWould you like to install one now?",
                yeslabel="Install Now",
                customlabel="Not Now",
            )
            if choice == 1:
                open_build_installer()
            return
        try:
            builds = wizard.list_builds()
        except Exception:
            return
        current = ADDON.getSetting("buildversion")
        for build in builds:
            if build.get("name") == buildname:
                if wizard._version_tuple(build.get("version", "0")) > wizard._version_tuple(current):
                    update = xbmcgui.Dialog().yesno(
                        "Nebula Wizard",
                        "%s update available.\nInstalled: %s\nLatest: %s"
                        % (buildname, current, build.get("version", "0")),
                        yeslabel="Update Now",
                        nolabel="Not Now",
                    )
                    if update:
                        open_build_installer()
                break
    except Exception as e:
        wizard.log("startup check failed: %s" % e)


if __name__ == "__main__":
    run_startup()
