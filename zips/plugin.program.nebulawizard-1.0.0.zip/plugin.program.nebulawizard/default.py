#!/usr/bin/env python3
"""Nebula Wizard - entry point."""

import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib import wizard

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")


def get_params(argv):
    params = {}
    if len(argv) > 2:
        query = argv[2].lstrip("?")
        params = dict(urllib.parse.parse_qsl(query))
    return params


class WizardWindow(xbmcgui.WindowXMLDialog):
    BTN_BUILD = 10
    BTN_ZIP = 11
    BTN_UPDATE = 12
    BTN_THEME = 13
    BTN_ABOUT = 14
    BTN_CLOSE = 15
    LBL_STATUS = 20

    def __init__(self, *args, **kwargs):
        self.status = ""

    def onInit(self):
        self.setStatus("Ready")
        if ADDON.getSettingBool("auto_prompt"):
            ADDON.setSetting("auto_prompt", "false")
            self.setStatus("Fetching builds ...")
            wizard.run_install_build()
            self.setStatus("Ready")

    def setStatus(self, text):
        self.status = text
        try:
            ctrl = self.getControl(self.LBL_STATUS)
            ctrl.setLabel(text)
        except Exception:
            pass

    def onClick(self, controlId):
        if controlId == self.BTN_BUILD:
            self.setStatus("Fetching builds ...")
            wizard.run_install_build()
            self.setStatus("Ready")
        elif controlId == self.BTN_ZIP:
            self.setStatus("Browsing for zip ...")
            wizard.run_install_zip()
            self.setStatus("Ready")
        elif controlId == self.BTN_UPDATE:
            self.setStatus("Checking for updates ...")
            wizard.run_update()
            self.setStatus("Ready")
        elif controlId == self.BTN_THEME:
            wizard.run_theme()
        elif controlId == self.BTN_ABOUT:
            wizard.run_about()
        elif controlId == self.BTN_CLOSE:
            self.close()

    def onAction(self, action):
        if action in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK):
            self.close()
            return True
        return super(WizardWindow, self).onAction(action)


def run_window():
    path = xbmcaddon.Addon().getAddonInfo("path")
    win = WizardWindow(
        "wizard_main.xml",
        ADDON_ID,
        "Default",
        "720p",
        True,
        path,
    )
    win.doModal()
    del win


def main():
    params = get_params(sys.argv)
    action = params.get("action")
    if action == "build":
        wizard.run_install_build()
    elif action == "zip":
        wizard.run_install_zip()
    elif action == "update":
        wizard.run_update()
    elif action == "theme":
        wizard.run_theme()
    elif action == "about":
        wizard.run_about()
    else:
        run_window()


if __name__ == "__main__":
    main()
