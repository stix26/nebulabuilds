#!/usr/bin/env python3
"""Nebula Wizard - core operations.

Handles builds from a hosted repository or a local folder, single-addon
zip installs, theme switching and update checks.
"""

import hashlib
import json
import os
import shutil
import urllib.error
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

HOME = xbmcvfs.translatePath("special://home/")
ADDONS_DIR = os.path.join(HOME, "addons")
TEMP = xbmcvfs.translatePath("special://temp/")

THEMES = ["Midnight", "Crimson", "Ocean", "Ember", "Emerald", "Violet"]


def log(msg):
    xbmc.log("[NebulaWizard] %s" % msg, xbmc.LOGINFO)


def notify(title, msg, icon="special://skin/media/logo.png"):
    xbmcgui.Dialog().notification(title, msg, icon, 5000)


def get_url(url, timeout=45):
    req = urllib.request.Request(url, headers={"User-Agent": "NebulaBuilds/1.0"})
    return urllib.request.urlopen(req, timeout=timeout).read()


def _split_list(raw):
    return [u.strip().rstrip("/") for u in raw.split(",") if u.strip()]


def get_base_urls():
    """Primary base URL first, then any mirrors. Tried in order."""
    return _split_list(ADDON.getSetting("base_url")) + \
        _split_list(ADDON.getSetting("mirrors"))


def _join(base, rel):
    return base.rstrip("/") + "/" + rel.lstrip("/")


def _is_local(base):
    return base.startswith("special://") or base.startswith("/") or \
        base.startswith("file://")


def fetch_first(rel):
    """Try each base URL until one serves rel; raise with the last error."""
    last = None
    for base in get_base_urls():
        url = _join(base, rel)
        try:
            data = get_url(url)
            log("fetched %s from %s" % (rel, base))
            return data, url
        except Exception as e:
            last = e
            log("mirror failed for %s: %s (%s)" % (url, e, type(e).__name__))
    raise RuntimeError("All repository URLs failed for %s: %s" % (rel, last))


def fetch_json(rel):
    data, _ = fetch_first(rel)
    return json.loads(data.decode("utf-8"))


def source_url(rel):
    """Local filesystem path for a repo file (first local base wins)."""
    for base in get_base_urls():
        if _is_local(base):
            return os.path.join(xbmcvfs.translatePath(base), rel)
    raise RuntimeError("No local repository URL configured for %s" % rel)


def ensure_local(rel):
    """Return a local filesystem path for rel, downloading if remote."""
    for base in get_base_urls():
        if _is_local(base):
            return os.path.join(xbmcvfs.translatePath(base), rel)
    dest = os.path.join(TEMP, os.path.basename(rel))
    data, _ = fetch_first(rel)
    log("downloading %s -> %s" % (rel, dest))
    with open(dest, "wb") as f:
        f.write(data)
    return dest


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def list_builds():
    return fetch_json("builds/builds.json")["builds"]


def _enable_addon(addon_id):
    try:
        xbmc.executebuiltin("Addon.SetEnabled(%s,true)" % addon_id)
    except Exception as e:
        log("could not enable %s: %s" % (addon_id, e))


def apply_theme(theme):
    if not ADDON.getSettingBool("auto_theme"):
        return
    if theme and theme in THEMES:
        try:
            xbmc.executebuiltin("Skin.SetTheme(%s)" % theme)
            log("theme applied: %s" % theme)
        except Exception as e:
            log("theme failed: %s" % e)


def extract_zip(zip_path, dest):
    log("extracting %s -> %s" % (zip_path, dest))
    if not xbmcvfs.exists(dest):
        xbmcvfs.mkdirs(dest)
    ok = xbmcvfs.extract(zip_path, dest)
    if not ok:
        raise RuntimeError("Failed to extract %s" % os.path.basename(zip_path))


def _remove_addon(addon_id):
    target = os.path.join(ADDONS_DIR, addon_id)
    if os.path.isdir(target):
        shutil.rmtree(target, ignore_errors=True)
        log("removed existing addon %s" % addon_id)


def install_addon_zip(zip_path):
    """Install a single addon zip (folder <addonid>/ at root)."""
    progress = xbmcgui.DialogProgress()
    progress.create("Nebula Wizard", "Installing addon ...")
    extract_zip(zip_path, ADDONS_DIR)
    progress.close()
    notify("Nebula Wizard", "Addon installed - restart recommended")
    return True


def install_build(build):
    """Install a build zip (contains addons/<id>/... and build.json)."""
    progress = xbmcgui.DialogProgress()
    progress.create("Nebula Wizard", build.get("name", "Build"))
    progress.update(0, "Downloading %s ..." % build.get("file", ""))

    local = ensure_local(_join("builds", build["file"]))
    if build.get("sha256"):
        progress.update(30, "Verifying download ...")
        actual = sha256_file(local)
        if actual != build["sha256"]:
            raise RuntimeError("Download failed integrity check - retry the build.")
    progress.update(45, "Extracting ...")
    extract_zip(local, HOME)
    progress.update(80, "Applying theme ...")
    apply_theme(build.get("theme"))
    progress.update(95, "Done")
    progress.close()

    notify("Nebula Wizard", "%s installed" % build.get("name"))
    return True


def _human_size(num):
    try:
        num = int(num)
    except (TypeError, ValueError):
        return "?"
    for unit in ("B", "KB", "MB", "GB"):
        if num < 1024 or unit == "GB":
            return "%d %s" % (num, unit) if unit == "B" else "%.1f %s" % (num, unit)
        num /= 1024.0
    return "?"


def pick_build(progress_cb=None):
    try:
        builds = list_builds()
    except Exception as e:
        notify("Nebula Wizard", "Could not load builds: %s" % e, xbmcgui.NOTIFICATION_ERROR)
        return None
    if not builds:
        notify("Nebula Wizard", "No builds found.", xbmcgui.NOTIFICATION_ERROR)
        return None

    items = ["%s v%s  (%s)" % (b["name"], b["version"], _human_size(b.get("size")))
             for b in builds]
    idx = xbmcgui.Dialog().select("Nebula Builds", items)
    if idx < 0:
        return None
    build = builds[idx]
    if not xbmcgui.Dialog().yesno("Nebula Wizard", "Install %s?" % build["name"],
                                  build.get("description", "")):
        return None
    return build


def run_install_build():
    build = pick_build()
    if not build:
        return
    try:
        install_build(build)
    except Exception as e:
        notify("Nebula Wizard", "Install failed: %s" % e, xbmcgui.NOTIFICATION_ERROR)
        return
    if xbmcgui.Dialog().yesno("Nebula Wizard", "Restart now to activate the build?"):
        xbmc.executebuiltin("Reboot")


def run_install_zip():
    path = xbmcgui.Dialog().browse(1, "Install addon zip", "files",
                                   ".zip", False, False)
    if not path:
        return
    try:
        install_addon_zip(path)
    except Exception as e:
        notify("Nebula Wizard", "Zip install failed: %s" % e, xbmcgui.NOTIFICATION_ERROR)
        return
    if xbmcgui.Dialog().yesno("Nebula Wizard", "Restart now?"):
        xbmc.executebuiltin("Reboot")


def run_theme():
    idx = xbmcgui.Dialog().select("Nebula Theme", THEMES)
    if idx >= 0:
        apply_theme(THEMES[idx])
        notify("Nebula Wizard", "Theme set to %s" % THEMES[idx])


def run_update():
    try:
        builds = list_builds()
        notify("Nebula Wizard", "%d build(s) available" % len(builds))
    except Exception as e:
        notify("Nebula Wizard", "Update check failed: %s" % e, xbmcgui.NOTIFICATION_ERROR)


def run_about():
    xbmcgui.Dialog().textviewer("Nebula Wizard",
                                "Nebula Builds\n\n"
                                "One-tap builds for Kodi 20-22.\n\n"
                                "Install Build  - fetch and install a build from the repository.\n"
                                "Install Zip    - install a single addon from a local zip.\n"
                                "Check Updates  - refresh the build list from the repository.\n"
                                "Nebula Theme   - switch the skin accent theme.\n\n"
                                "Set the repository URL in the add-on settings.")
